<?php 
if(isset($_GET['appartement']) && !empty($_GET['appartement'])){
	require"AppartementDb.php";
  $id =$_GET['appartement'];
    // insertion dans la base de donnees 
  $req=$pdo->prepare("SELECT * from locations WHERE appartement='$id'");
  $req->execute(array($id));
  $compter=$req->rowCount();

  if($compter > 0){
  	while ($row=mysqli_fetch_array($req)) {
  		echo '<option value="'.$list['id_locations'].'">'.$list['location'].'</option>';

  	}
  }else{
  	echo'<p>error</p>';
  }





}
?>






