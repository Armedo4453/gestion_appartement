<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>appartement No 1 </title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js



"></script>
  <script>
   function getState(val)
   {

    $.ajax({
      type:"POST",
      url:"get_state.php",
      data: 'id_appartement='+val,
      success:function(data){
        $("#state-list").html(data);

      }
    });
   }
 </script>

  
  <!-- =======================================================
    Theme Name: NiceAdmin
    Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body style="background-color:#2e8b57;">
  <?php 
  require"AppartementDb.php";
 

   ?>
  <!-- container section start -->
  <section id="container" class="">


    <header class="header dark-bg" style="background-color: green">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="index.html" class="logo">vous utilisez l'application de gestion de votre appartement<span class="lite"></span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
      
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

        
      
           
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                           
                            <span class="username">Armedo NISHIRIMBERE</span>
                            
         
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <?php include"navbar/navbar.html"; ?>
    <!--sidebar end-->

    <!--main content start-->

    <section id="main-content">
      <section class="wrapper">
        <p style="color: white;font-size: 30px; background-color:gray">     

        Locataires Appartement No 1</p>


        <!--overview start-->

        <form method="POST">
          <table>
            <tr>
              <td>

                <select class="form-control" name="selectMenu">
                  <option disabled="">...choisir.....</option>
                  <option value="1">Locataires</option>
                </select>
              </td>
              <td><input type="submit" class="btn btn-primary" value="Afficher" name="submit"></td>
            </tr>
          </table>

        </form>
         
        

        
           <?php 

        if(isset($_POST['selectMenu'])){
          $selectMenu=$_POST['selectMenu'];
          switch ($selectMenu) {
            case '1':
              $stmt=$pdo->query("SELECT * from locataires where appartement='1' ");
              break;
            default:


              break;
          }
           echo '

          <section class="panel">
        <header class="panel-heading">
               tables des locataires Appartement No 1
              </header>
          <table class="table">
            <tr>
              <th>id</th>
              <th>nom locataire</th>
              <th>sexe</th>
              <th>adresse</th>
              <th>numero</th>
              <th>CNI</th>
              <th>date Entree</th>
              <th>date Sortie</th>
              <th>Appartement</th>
              <th>montant</th>
            </tr>';


         while ($row=$stmt->fetch()){
          
           ?>
   

           <tr>

            <td><?php echo $row['id_locataire']  ;  ?></td>
            <td><?php echo $row['nom_locataire']  ;  ?></td>
            <td><?php echo $row['sexe']; ?></td>
            <td><?php echo $row['adresse']; ?></td>
            <td><?php echo $row['numero']; ?></td>
            <td><?php echo $row['CNI']; ?></td>
            <td><?php echo $row['dateEntree']; ?></td>
            <td><?php echo $row['dateSortie']; ?></td>
            <td><?php echo $row['appartement']; ?></td>
            <td><?php echo $row['montantPaye']; ?></td>
          </tr>
           

           
           <?php  }
        ?>
         <?php } ?>
        </table>
      </section>




        <section class="wrapper">
      <p style="color: white;font-size: 30px; background-color:gray">     

        Depenses appartement No 1</p>


        <!--overview start-->

        <form method="POST">
          <table>
            <tr>
              <td>

                <select class="form-control" name="select">
                  <option disabled="">...choisir.....</option>
                  <option value="2">depenses</option>
                </select>
              </td>
              <td><input type="submit" class="btn btn-primary" value="Afficher" name="submit"></td>
            </tr>
          </table>

        </form>
        

        
           <?php 

        if(isset($_POST['select'])){
          $select=$_POST['select'];
          switch ($select) {
            case '2':
              $recupdata=$pdo->query("SELECT * from depenses where appartement='1' ");
              break;
            default:


              break;
          }
       

         echo'
          <section class="panel">
        <header class="panel-heading">
               tables des Depenses Appartement No 1
              </header>
          <table class="table">
            <tr>
              <th>Id</th>
              <th>Employeur</th>
              <th>Appartement</th>
              <th>Motif</th>
              <th>Date</th>
              <th>montant Depense</th>
              
            </tr>
         ';

        

         while ($row=$recupdata->fetch()){
           ?>
   
        

           <tr>
            <td><?php echo $row['id_depense'] ?></td>
                    <td><?php echo $row['nom_depense'] ?></td>
                    <td><?php echo $row['appartement'] ?></td>
                    <td><?php echo $row['motif'] ?></td>
                    <td><?php echo $row['date'] ?></td>
                    <td><?php echo $row['montantDepense'] ?> Fbu</td>

            
          </tr>
           
           
           <?php  }
        ?>
         <?php } ?>
        </table>
      </section>
    </section>
    
           </section>

          </section>
             




               

 <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
      
        <form method="get" action="appartement1Print.php" style="background-color: gray;padding:10px;">
         
          <table style=""> 
            <tr>  
              <td>  
                 
                <label style="color: white">Date du debut</label>
               <input type="date" name="txtStartDate" class="form-control" style="width: 150%">
             
              </td>
              <td>   <label style="visibility: hidden;">Date de fin</label>
          <input type="date" name="txtEndDate" class="form-control" style="visibility: hidden;"></td>
              
              <td>  
                 <label style="color: white">Date de fin</label>
          <input type="date" name="txtEndDate" class="form-control" style="width: 150%">

              </td>
            </tr>

          </table><br>
          <p>
            <input type="submit" name="search" value="Rechercher ..." class="btn btn-primary">
           
          
        </form>

      
        <!--/.row-->
          


       


        <!-- Today status end -->



      


        <!-- statics end -->




        <!-- project team & activity start -->
       

       
        <!-- project team & activity end -->

      </section>
      <div class="text-right">
        <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
          Designed by Armel Nishirimbere
        </div>
      </div>
    </section>
       <!--               
                  
                 
              
          <form>
           
            <select id="country-list" onchange="getState(this.value);">
              <option value="">select Appartement</option>
               <?php 
                     $recupdata=$pdo->prepare("SELECT * from appartements");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){ 

                     ?>
                     <option value="<?php echo $list['id_appartement'] ?> "> <?php echo $list['appartement'] ?></option>
                   <?php } ?>
            </select>
           

            <select id="state-list" >

              <option value="" >select Location</option>
            </select>
          </form>
-->
        


          
       
              
        

      
     
       
        
            <!--/.info-box-->
          </div>
          <!--/.col-->

          
          <!--/.col-->

        </div>
        <!--/.row-->


       


        

      </section>
      <div class="text-right">
        <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
         
        </div>
      </div>
    </section>
    <!--main content end-->
 
  <!-- container section start -->

  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <<script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
 
    <!--
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>-->

</body>

</html>
