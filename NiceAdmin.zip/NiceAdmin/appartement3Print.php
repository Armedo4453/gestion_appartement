<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>page d'impression</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="print.css" media="print">
  
  <!-- =======================================================
    Theme Name: NiceAdmin
    Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body style="background-color:white;">
  <?php 
  require"AppartementDb.php";
  require"scripts/searchRapport_script.php";

   ?>
  <!-- container section start -->
  <section id="container" class="">



     <div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading" style="font-size:20px;color:black;">
               <center>RESULTAT DE RECHERCHE DES LOCATAIRES APPARTEMENT No 3 ENTRE
               <?php 
              if (isset($_GET['search']) and !empty($_GET
                ['txtStartDate'])){
              $txtStartDate=htmlspecialchars($_GET['txtStartDate']);
              $txtEndDate=htmlspecialchars($_GET['txtEndDate']);
              echo ''.$txtStartDate.' et '.$txtEndDate.'</p>';
               ?>
              
            </center>
              </header>
           


             


               
<?php  
//connexion(formulaire avec base de donnees)
if(isset($_GET['search'])){
  $txtStartDate =htmlspecialchars($_GET['txtStartDate']);
  $txtEndDate =htmlspecialchars($_GET['txtEndDate']);
  if (! empty($_GET['txtStartDate']) and !empty($_GET['txtEndDate'])){
    // insertion dans la base de donnees 
  $req=$pdo->prepare("SELECT * from locataires WHERE dateEntree between '$txtStartDate' and '$txtEndDate' and appartement='3'");

  $req->execute(array($txtStartDate,$txtEndDate));
  $compter=$req->rowCount();
}
 ?>



 <?php
         $recupdata=$pdo->prepare("SELECT count(id_locataire) from locataires WHERE dateEntree between '$txtStartDate' and '$txtEndDate' and appartement='3'");
         $recupdata->execute();
         while ($list=$recupdata->fetch()){

           ?>    
              <?php
                if( $list['count(id_locataire)'] <1){
              echo '<center><p style="color:red;">aucun resultat pour cette recherche</p></center>';
              

            }else {
              
              echo '<table class="table">

                <thead>
                  <tr>
                    <th>Id Locataire</th>
                    <th>nom client</th>
                    <th>sexe</th>
                    <th>adresse</th>
                    <th>numero</th>
                    <th>CNI</th>
                    <th>date Entree</th>
                    <th>date Sortie</th>
                    <th>Appartement</th>
                    <th>montant paye</th>
                 
                   
                  </tr>
                </thead>
                <tbody>';
            }

            
               ?>
               
             <?php }

             ?>



   
            <?php 
                   $recupdata=$pdo->prepare("SELECT * from locataires WHERE dateEntree between '$txtStartDate' and '$txtEndDate' and appartement='3'");
                    $recupdata->execute();
                      while ($list=$recupdata->fetch()){   ?>

                  <tr>
                     
                    <td><?php echo $list['id_locataire']; ?></td>
                    <th><?php echo $list['nom_locataire']; ?></th>
                    <td><?php echo $list['sexe']; ?></td>
                    <td><?php echo $list['adresse']; ?></td>
                    <td><?php echo $list['numero']; ?></td>
                    <td><?php echo $list['CNI']; ?></td>
                    <td><?php echo $list['dateEntree']; ?></td>
                    <td><?php echo $list['dateSortie']; ?></td>
                    <td><?php echo $list['appartement'] ?></td>
                    <td><?php echo $list['montantPaye']; ?>Fbu</td>

                     
                     
                    

        
                     
                    

                    </td>
                    
                  </tr>
                  <?php } ?>

                  <tr>
                       <td>Montant Total</td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>

                     
                        <?php 
                     $recupdata=$pdo->prepare("SELECT sum(montantPaye) from locataires WHERE dateEntree between '$txtStartDate' and '$txtEndDate' and appartement='3'");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){   


                     ?>

                     <th> <?php

                      echo $list['sum(montantPaye)']  ?> Fbu</th>
                       
                       <?php } ?>
                       <?php } ?>
                       </td>
                    
                     </tr>


                  
                  <?php } ?>
                </tbody>
              </table>

              <table>
                
              </table>

            </section>

             <section id="container" class="">



     <div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading" style="font-size:20px;color:black;">
               <center>RESULTAT DE RECHERCHE DES DEPANSES APPARTEMENT No 3 ENTRE
               <?php 
              if (isset($_GET['search']) and !empty($_GET
                ['txtStartDate'])){
              $txtStartDate=htmlspecialchars($_GET['txtStartDate']);
              $txtEndDate=htmlspecialchars($_GET['txtEndDate']);
              echo ''.$txtStartDate.' et '.$txtEndDate.'</p>';
               ?>
              
            </center>
              </header>
           


             


               
<?php  
//connexion(formulaire avec base de donnees)
if(isset($_GET['search'])){
  $txtStartDate =htmlspecialchars($_GET['txtStartDate']);
  $txtEndDate =htmlspecialchars($_GET['txtEndDate']);
  if (! empty($_GET['txtStartDate']) and !empty($_GET['txtEndDate'])){
    // insertion dans la base de donnees 
  $req=$pdo->prepare("SELECT * from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");

  $req->execute(array($txtStartDate,$txtEndDate));
  $compter=$req->rowCount();
}
 ?>



 <?php
         $recupdata=$pdo->prepare("SELECT count(id_depense) from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");
         $recupdata->execute();
         while ($list=$recupdata->fetch()){

           ?>    
              <?php
                if( $list['count(id_depense)'] <1){
              echo '<center><p style="color:red;">aucun resultat pour cette recherche</p></center>';
              

            }else {
              
              echo '<table class="table">

                <thead>
                  <tr>
                    <th>Id depense</th>
                    <th>employeur</th>
                    <th>Appartement</th>
                    <th>motif</th>
                    <th>date</th>
                    <th>montant</th>
                    
                 
                   
                  </tr>
                </thead>
                <tbody>';
            }

            
               ?>
               
             <?php }

             ?>

   
            <?php 
                   $recupdata=$pdo->prepare("SELECT * from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");
                    $recupdata->execute();
                      while ($list=$recupdata->fetch()){   ?>

                  <tr>
                     
                    <td><?php echo $list['id_depense'] ?></td>
                    <td><?php echo $list['nom_depense'] ?></td>
                    <td><?php echo $list['appartement'] ?></td>
                    <td><?php echo $list['motif'] ?></td>
                    <td><?php echo $list['date'] ?></td>
                    <td><?php echo $list['montantDepense'] ?> Fbu</td>
                     
                     
                </td>
            
                  </tr>
                  <?php } ?>

                  <tr>
                       <td>Montant Total</td>
                       <td></td>
                       <td></td>
                       <td></td>
                       <td></td>
                     
                     

                     
                        <?php 
                     $recupdata=$pdo->prepare("SELECT sum(montantDepense) from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){   


                     ?>

                     <th> <?php

                      echo $list['sum(montantDepense)'] ?> Fbu</th>
                       
                       <?php } ?>
                       <?php } ?>
                       </td>
                    
                     </tr>

            

                  
                  <?php } ?>
                </tbody>
              </table>

              <table>
                
              </table>

            </section>


              
          </div>
         
        </div>

 



          
       
              
        

      
     
       
        
            <!--/.info-box-->
          </div>
          <!--/.col-->

          
          <!--/.col-->

        </div>
        <!--/.row-->


       


        

      </section>


              
          </div>
         
        </div>

        <table>
          <tr>
            <th>entres</th>
            <th>depenses</th>
            <th>benefice</th>
          </tr>
          <form method="get">
          <tr>
            <td>
              <?php  
//connexion(formulaire avec base de donnees)
if(isset($_GET['search'])){
  $txtStartDate =htmlspecialchars($_GET['txtStartDate']);
  $txtEndDate =htmlspecialchars($_GET['txtEndDate']);
  if (! empty($_GET['txtStartDate']) and !empty($_GET['txtEndDate'])){
    // insertion dans la base de donnees 
  $req=$pdo->prepare("SELECT * from locataires  WHERE dateEntree  between '$txtStartDate' and '$txtEndDate' and appartement='3'");

  $req->execute(array($txtStartDate,$txtEndDate));
  $compter=$req->rowCount();
}
 ?>

               <?php 
                     $recupdata=$pdo->prepare("SELECT sum(montantPaye) from locataires WHERE dateEntree between '$txtStartDate' and '$txtEndDate' and appartement='3' ");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){   


                     ?>

               


                     <input type="text" name="loc" id="locataire1"  value=" <?php echo $list['sum(montantPaye)'] ?>"> 

                       
                       <?php } ?> <?php } ?>
            </td>
            <td>
              <?php  
//connexion(formulaire avec base de donnees)
if(isset($_GET['search'])){
  $txtStartDate =htmlspecialchars($_GET['txtStartDate']);
  $txtEndDate =htmlspecialchars($_GET['txtEndDate']);
  if (! empty($_GET['txtStartDate']) and !empty($_GET['txtEndDate'])){
    // insertion dans la base de donnees 
  $req=$pdo->prepare("SELECT * from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");

  $req->execute(array($txtStartDate,$txtEndDate));
  $compter=$req->rowCount();
}
 ?>

               <?php 
                     $recupdata=$pdo->prepare("SELECT sum(montantDepense) from depenses WHERE date between '$txtStartDate' and '$txtEndDate' and appartement='3'");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){   


                     ?>

                    

                     <input type="text" name="dep" id="depense1"  value="">

                       
                       <?php } ?> <?php } ?>
              
            </td>
            <td>
               <input type="text" name="ben" id="benefice1">
            </td>
          </tr>

        </table>

          
          
         
       

                      
     
          
     
         
        </form>
<br>  
  <div>
     <button onclick="window.print()" class="btn btn-primary" id="print-btn">Imprimer</button>
  </div>

    
     
       
        
            <!--/.info-box-->
          </div>
          <!--/.col-->

          
          <!--/.col-->

        </div>
        <!--/.row-->
      


       


        

      </section>

      <div class="text-right">
        <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
         <!-- Designed by Armel Nishirimbere -->
         
        </div>
      </div>
    </section>
    <!--main content end-->
  </section>
  <!-- container section start -->

  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <!--
    <script>
      //knob
   $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>


-->
<script type="text/javascript">
  function benefice(){
    var locataire1=document.getElementById("locataire1").value;
    var depense1=document.getElementById("depense1").value;
    var benefice1=document.getElementById("benefice1");
    benefice1.value=parseInt(locataire1)-parseInt(depense1);

  }
  var locataire1=document.getElementById("locataire1");
  var depense1=document.getElementById("depense1");
  var benefice1=document.getElementById("benefice1");
  locataire1.addEventListener("change", benefice, false);
  depense1.addEventListener("change", benefice, false);

</script>







<script type="text/javascript">
  $(document).ready(function(){

  $('#appartement').on('change',function(){
    var appartementID=$(this).val();
    if(appartementID){
      $.get(
        "ajax.php",
        {appartement: appartementID},
        function(data){
          $('#location').html(data);

        }
        );
    }else{
      $('#location').html('<option>select appartement first</option>');

    }
  });
  });
</script>
</body>

</html>
