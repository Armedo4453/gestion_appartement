<?php
require"AppartementDb.php";
if (isset($_GET['id_appartement'])) {
	$supr=intval($_GET['id_appartement']);
	$del=$pdo->prepare("DELETE  FROM appartements WHERE id_appartement=?");
	$del->execute(array($supr));
	header("location:Appartement.php");
}

?>