<?php
require"AppartementDb.php";
if (isset($_GET['id_depense'])) {
	$supr=intval($_GET['id_depense']);
	$del=$pdo->prepare("DELETE  FROM depenses WHERE id_depense=?");
	$del->execute(array($supr));
	header("location:depenses.php?start=0");
}

?>