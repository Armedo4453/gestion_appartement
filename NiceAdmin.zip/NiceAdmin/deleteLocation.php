<?php
require"AppartementDb.php";
if (isset($_GET['id_locations'])) {
	$supr=intval($_GET['id_locations']);
	$del=$pdo->prepare("DELETE  FROM locations WHERE id_locations=?");
	$del->execute(array($supr));
	header("location:locations.php");
}

?>