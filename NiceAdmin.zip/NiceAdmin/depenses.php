<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>depense</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <!-- =======================================================
    Theme Name: NiceAdmin
    Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body style="background-color:#2e8b57;">
  
<?php require"AppartementDb.php";
      require"scripts/depense_script.php";
     

 ?>

  <!-- container section start -->
  <section id="container" class="">


    <header class="header dark-bg" style="background-color: green">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="index.html" class="logo">vous utilisez l'application de gestion de votre appartement<span class="lite"></span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
      
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

        
      
           
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                           
                            <span class="username">Armedo NISHIRIMBERE</span>
                            
         
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <?php include"navbar/navbar.html"; ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
       
        </div>
      
       

        <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"><b style="">+</b>Ajouter une depense</button>
 <br><br>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ajout des depenses</h4>
      </div>
      <div class="modal-body">
        <form method="post">
              <center>
               <?php
             if(isset($error)){
               echo "<div class='alert alert-danger col-md-12'>
                    <button type='button' class='close' data-dismiss='alert'></button>"
                    .$error.
                    "</div>";
             }
              ?>
        
       </center>

   
   <center>
          <div style="font-size: 20px;" id="success">
            <?php
             if(isset($success)){
               echo "<div class='alert alert-success col-md-12'>
                    <button type='button' class='close' data-dismiss='alert'></button>"
                    .$success.
                    "</div>";
             }
              ?>
                
              </div>
            </center>
             <div class="form-group">
                <label>Nom d'employeur</label>
                <input type="text" name="employeur" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Appartement</label>
               <select id="country-list" name="appartement" class="form-control" onchange="getState(this.value);">
              <option value="">select Appartement</option>
               <?php 
                     $recupdata=$pdo->prepare("SELECT * from appartements order by id_appartement");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){ 

                     ?>
                     <option class="form-group" value="<?php echo $list['id_appartement'] ?> "> <?php echo $list['appartement'] ?></option>
                   <?php } ?>
            </select>
            </div>
             
              <div class="form-group">
                <label>motif</label>
                <input type="text" name="motif" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>date</label>
                <input type="date" name="date" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>montant depense</label>
                <input type="text" name="montant" class="form-control" required/>
              </div>
               <div class="form-group">
              
                <input type="submit" value="Ajouter" name="submit" class="btn btn-info"  required/>
              </div>
              
            </form>
       


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div> 
         

         <div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading">
               tables des depenses
              </header>


              <table class="table">

                <thead>
                  <tr>
                    <th>Id depense</th>
                    <th>responsable</th>
                    <th>appartement</th>
                    <th>motif</th>
                    <th>date</th>
                    <th>montant depense</th>
                    <th>Parametres</th>
                   
                  </tr>
                </thead>
                <tbody>
                  <tr>
                     <?php 

        $numeparpage=10;
        $recupdata=$pdo->prepare("SELECT COUNT(id_depense) from depenses ");
        $recupdata->execute();
        $row=$recupdata->fetch();
        $numerecords=$row[0];
        $numlinks= ceil( $numerecords/$numeparpage);
        echo" numero de pagination est ".$numlinks.'</br>';
        $page=$_GET['start'];
        if(!$page) $page=0;
        $start=$page * $numeparpage;
       ?>
                    <?php 
                   $recupdata=$pdo->prepare("SELECT * from depenses left join appartements on depenses.appartement=appartements.id_appartement ");
         $recupdata->execute();
         while ($list=$recupdata->fetch()){   
                   ?>
                    <td><?php echo $list['id_depense'] ?></td>
                    <td><?php echo $list['nom_depense'] ?></td>
                    <td><?php echo $list['appartement'] ?></td>
                    <td><?php echo $list['motif'] ?></td>
                    <td><?php echo $list['date'] ?></td>
                    <td><?php echo $list['montantDepense'] ?> Fbu</td>
                    
                    
                    <td>
                      <a onClick="return confirm('voulez vous modifier?')" href="editerDepense.php?id_depense=<?php echo $list['id_depense'];?>"><button class="btn btn-large btn-primary" type="button">Editer</button></a>

                       <a onclick=" return confirm('voulez vous supprimer?')" href="deleteDepense.php?id_depense=<?php echo $list['id_depense'];?>"><button class="btn btn-large btn-danger" type="button">Supprimer</button></a>


                       


     
                    </td>
                  </tr>
               
                  <?php } ?>
                 
                </tbody>
              </table>
              <center>
                 <ul class="pagination">
           
   <li>
            <?php
       //$numeparpage * $start;
        for($i=0;$i<$numlinks;$i++){
          $y=$i+1;
        echo '<a  href="depenses.php?start='.$i.' ">'.$y.'</a> ';
      } ?>
      </li>
                 
                
           
      </ul> </center>
            </section>
          </div>
         
        </div>

   


      </section>
      <div class="text-right">
        <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
          Designed by Armel Nishirimbere
        </div>
      </div>
    </section>
    <!--main content end-->
  </section>
  <!-- container section start -->

  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <<script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>

</body>

</html>
