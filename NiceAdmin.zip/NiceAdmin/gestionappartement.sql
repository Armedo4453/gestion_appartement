-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 05, 2023 at 07:57 AM
-- Server version: 5.7.36
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestionappartement`
--

-- --------------------------------------------------------

--
-- Table structure for table `appartements`
--

DROP TABLE IF EXISTS `appartements`;
CREATE TABLE IF NOT EXISTS `appartements` (
  `id_appartement` int(255) NOT NULL AUTO_INCREMENT,
  `appartement` varchar(255) NOT NULL,
  `etat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_appartement`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appartements`
--

INSERT INTO `appartements` (`id_appartement`, `appartement`, `etat`) VALUES
(1, 'appartement No 1', 'desactiver'),
(2, 'appartement No 2', 'activer'),
(5, 'appartement No 5', 'activer'),
(3, 'appartement No 3', 'activer'),
(4, 'appartement No 4', 'activer');

-- --------------------------------------------------------

--
-- Table structure for table `depenses`
--

DROP TABLE IF EXISTS `depenses`;
CREATE TABLE IF NOT EXISTS `depenses` (
  `id_depense` int(255) NOT NULL AUTO_INCREMENT,
  `nom_depense` varchar(255) NOT NULL,
  `motif` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `montantDepense` varchar(255) NOT NULL,
  `appartement` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_depense`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depenses`
--

INSERT INTO `depenses` (`id_depense`, `nom_depense`, `motif`, `date`, `montantDepense`, `appartement`) VALUES
(10, 'dufisumukiza igor', 'achat des dras', '2021-06-25', '10000', '3 '),
(9, 'dufisumukiza igor', 'lavage des locaux', '2021-06-24', '20000', '1 '),
(8, 'nishirimbere armel', 'vente des savons', '2021-06-23', '1000', '1 ');

-- --------------------------------------------------------

--
-- Table structure for table `locataires`
--

DROP TABLE IF EXISTS `locataires`;
CREATE TABLE IF NOT EXISTS `locataires` (
  `id_locataire` int(255) NOT NULL AUTO_INCREMENT,
  `nom_locataire` varchar(255) NOT NULL,
  `sexe` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `numero` varchar(255) NOT NULL,
  `CNI` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `appartement` varchar(50) NOT NULL,
  `montantPaye` varchar(50) NOT NULL,
  `dateEntree` date DEFAULT NULL,
  `dateSortie` date DEFAULT NULL,
  PRIMARY KEY (`id_locataire`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locataires`
--

INSERT INTO `locataires` (`id_locataire`, `nom_locataire`, `sexe`, `adresse`, `numero`, `CNI`, `date`, `appartement`, `montantPaye`, `dateEntree`, `dateSortie`) VALUES
(34, 'kaneza Pierre', 'Homme', 'inconnue', '00000000', '003/39.892', '2021-06-24 06:49:40', '4 ', '50000', '2021-06-25', '2021-06-26'),
(33, 'armel nishirimbere', 'Homme', 'mugina', '69000000', '209/67.000', '2021-06-24 06:48:52', '2 ', '100000', '2021-06-16', '2021-06-26'),
(32, 'kaneza Pierre', 'Homme', 'inconnue', '71000000', '003/39.892', '2021-06-24 06:24:47', '1 ', '12500', '2021-06-23', '2021-06-25'),
(31, 'kaneza peteroniya', 'Homme', 'mugina', '69000000', '209/67.623', '2021-06-23 10:37:47', '3 ', '200000', '2021-06-23', '2021-06-23'),
(29, 'armel nishirimbere', 'Homme', 'inconnue', '679097567', '003/39.892', '2021-06-23 09:34:16', '3 ', '50000', '2021-06-16', '2021-06-24'),
(30, 'armella nishirimbero', 'Homme', 'kibenga', '71000000', '209/67.000', '2021-06-23 10:35:04', '1 ', '30000', '2021-06-08', '2021-06-08');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id_locations` int(255) NOT NULL AUTO_INCREMENT,
  `appartement` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `statut` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_locations`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id_locations`, `appartement`, `location`, `statut`) VALUES
(1, '1 ', 'chambre 1', 'activer'),
(3, '2 ', 'chambre 1', 'activer'),
(4, '3 ', 'chambre 1', 'activer'),
(5, '4 ', 'chambre 1', 'activer'),
(2, '5 ', 'chambre 1', 'activer');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `id_reservation` int(255) NOT NULL AUTO_INCREMENT,
  `nom_locataire` varchar(255) NOT NULL,
  `sexe` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `numero` varchar(255) NOT NULL,
  `CNI` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `location` varchar(50) NOT NULL,
  `montantPaye` varchar(50) NOT NULL,
  `montantReste` varchar(50) NOT NULL,
  `situation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_reservation`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id_reservation`, `nom_locataire`, `sexe`, `adresse`, `numero`, `CNI`, `date`, `location`, `montantPaye`, `montantReste`, `situation`) VALUES
(12, 'kaneza peterooooo', 'Homme', 'inconnue', '71000000', '209/67.623', '2021-06-25', '4', '40000', '222', NULL),
(9, 'kaneza jeanne', 'Femme', 'inconnue', '71000000', '209/67.623', '2021-06-15', '1', '10000', '5000', NULL),
(10, 'kaneza \r\npetero', 'Femme', 'kanyosha', '69000000', '003/39.892', '2021-06-15', '3', '20000', '10000', NULL),
(11, 'ciza claude', 'Homme', 'kanyosha', '679097567', '003/39.892', '2021-06-23', '3', '30000', '33333', NULL),
(8, 'kaneza Pierree', 'Homme', 'mutambu', '69554470', '209/67.621', '2021-06-22', '1', '20000', '10000', 'desactiver');

-- --------------------------------------------------------

--
-- Table structure for table `usersapprtm`
--

DROP TABLE IF EXISTS `usersapprtm`;
CREATE TABLE IF NOT EXISTS `usersapprtm` (
  `IdUsers` int(255) NOT NULL AUTO_INCREMENT,
  `Nom_Users` varchar(255) NOT NULL,
  `EmailUsers` varchar(255) NOT NULL,
  `passwords` varchar(255) NOT NULL,
  `etatt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IdUsers`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersapprtm`
--

INSERT INTO `usersapprtm` (`IdUsers`, `Nom_Users`, `EmailUsers`, `passwords`, `etatt`) VALUES
(4, 'NISHIRIMBERE Armel', 'armedonishirimbere@gmail.com', '01b307acba4f54f55aafc33bb06bbbf6ca803e9a', NULL),
(3, 'MUTIMA aline', 'aline@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', NULL),
(6, 'thierry  ', 'thierry@gmail.com', '169f0dcbf6429279bf0a04f081cc21f1c1a1c595', 'activer'),
(8, 'NISHIRIMBERE Armel', 'armedonishirimbere@gmail.com', '01b307acba4f54f55aafc33bb06bbbf6ca803e9a', 'activer');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
