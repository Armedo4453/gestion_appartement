<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	  <option>select Location</option>
	<?php 

	include"AppartementDb.php";
    $recupdata=$pdo->prepare("SELECT * from locations where appartement='".$_POST['id_appartement']."' and statut='activer' ");
    $recupdata->execute();
    while ($list=$recupdata->fetch()){   
                     ?>
  
    <option value="<?php echo $list['id_locations']; ?>"><?php echo $list['location'] ?></option>


     <?php } ?> 
	

</body>
</html>






