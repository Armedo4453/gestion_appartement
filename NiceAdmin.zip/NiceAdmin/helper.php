<?php 
require"AppartementDb.php";
$var=$_GET['value'];

$val_M=mysql_real_escape_string($pdo,$val);
$recupdata=$pdo->prepare("SELECT * from locatires where appartement='$val_M'");
 $recupdata->execute();
 while ($list=$recupdata->fetch()){ ?>

<?php echo "<select>" ?>

 }



 ?>