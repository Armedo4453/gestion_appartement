<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>locataires</title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.min.js



"></script>
  <script>
   function getState(val)
   {

    $.ajax({
      type:"POST",
      url:"get_state.php",
      data: 'id_appartement='+val,
      success:function(data){
        $("#state-list").html(data);

      }
    });
   }
 </script>
  <!-- =======================================================
    Theme Name: NiceAdmin
    Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body style="background-color:#2e8b57;">
  
<?php require"AppartementDb.php";

      require"scripts/ajouterLocataire_script.php";
     

 ?>

  <!-- container section start -->
  <section id="container" class="">


    <header class="header dark-bg" style="background-color: green">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="index.html" class="logo">vous utilisez l'application de gestion de votre appartement<span class="lite"></span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
      
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

        
      
           
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                           
                            <span class="username">Armedo NISHIRIMBERE</span>
                            
         
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
   <?php include"navbar/navbar.html"; ?>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
       
        </div>
      
       

      
        <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"><b style="">+</b>Ajouter un Locataire</button>
        <button type="button" style="visibility: hidden;" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"><b style="">+</b>Ajouter un Appartement</button>
         <button type="button" style="visibility: hidden;" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"><b style="">+</b>Ajouter un Appartement</button>

        <button type="button" class="btn btn- btn-lg" data-toggle="" data-target=""><?php 
         $recupdata=$pdo->prepare("SELECT count(id_locataire) from locataires");
         $recupdata->execute();
         while ($list=$recupdata->fetch()){   
         echo "nous avons ".$list['count(id_locataire)']." locataire";
         if( $list['count(id_locataire)'] >1){
          echo "s";}

         ?> 
           <?php } ?></button>

        <br><br>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ajout des Locataires</h4>
      </div>
      <div class="modal-body">
        <form method="post">
              <center>
               <?php
             if(isset($error)){
               echo "<div class='alert alert-danger col-md-12'>
                    <button type='button' class='close' data-dismiss='alert'></button>"
                    .$error.
                    "</div>";
             }
              ?>
        
       </center>

   
   <center>
          <div style="font-size: 20px;" id="success">
            <?php
             if(isset($success)){
               echo "<div class='alert alert-success col-md-12'>
                    <button type='button' class='close' data-dismiss='alert'></button>"
                    .$success.
                    "</div>";
             }
              ?>
                
              </div>
            </center>
             

             <div class="form-group">
                <label>Nom du Locataire</label>
                <input type="text" name="locataire" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Sexe</label>
                <select class="form-control" name="sexe">
                  <option>Homme</option>
                  <option>Femme</option>
                </select>
              </div>

              <div class="form-group">
                <label>Adresse</label>
                <input type="text" name="adresse" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Numero Tel</label>
                <input type="text" name="numero" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Numero CNI</label>
                <input type="text" name="CNI" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Date d'entree</label>
                <input type="date" name="dateEntree" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Date de sortie</label>
                <input type="date" name="dateSortie" class="form-control" required/>
              </div>
              <div class="form-group">
                <label>Appartement</label>
               <select id="country-list" name="appartement" class="form-control" onchange="getState(this.value);">
              <option value="">select Appartement</option>
               <?php 
                     $recupdata=$pdo->prepare("SELECT * from appartements order by id_appartement");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){ 

                     ?>
                     <option class="form-group" value="<?php echo $list['id_appartement'] ?> "> <?php echo $list['appartement'] ?></option>
                   <?php } ?>
            </select>
            </div>
  
               <div class="form-group">
                <label>Montant paye</label>
                <input type="text" name="montantpay" class="form-control" required/>
              </div>
               <div class="form-group">
               
                <input type="submit" name="submit" class="btn btn-primary" value="ajouter" required/>
              </div>

             

              
              
            </form>
       


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div> 
         

         <div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading" >
               tables des Locataires
              </header>


              <table class="table">

                <thead>
                  <tr>
                    <th>Id Locataire</th>
                    <th>nom client</th>
                    <th>sexe</th>
                    <th>adresse</th>
                    <th>numero</th>
                    <th>CNI</th>
                    <th>date d'entree</th>
                    <th>date de sortie</th>
                   <th>appartement</th>
                
                    <th>montant paye</th>
                    <th>Parametres</th>
                   
                  </tr>
                </thead>
                <tbody>

                
                    <?php 

        $numeparpage=7;
        $recupdata=$pdo->prepare("SELECT COUNT(id_locataire) from locataires  ");
        $recupdata->execute();
        $row=$recupdata->fetch();
        $numerecords=$row[0];
        $numlinks= ceil( $numerecords/$numeparpage);
        echo" numero de pagination est ".$numlinks.'</br>';
        $page=$_GET['start'];
        if(!$page) $page=0;
        $start=$page * $numeparpage;
       ?>
  
        <?php $recupdata=$pdo->prepare("SELECT * from locataires left join appartements on locataires.appartement=appartements.id_appartement order by id_locataire desc limit $start, $numeparpage ");
         $recupdata->execute();
         while ($list=$recupdata->fetch()){ ?>

            <tr>
                   <td><?php echo $list['id_locataire']; ?></td>
                    <th><?php echo $list['nom_locataire']; ?></th>
                    <td><?php echo $list['sexe']; ?></td>
                    <td><?php echo $list['adresse']; ?></td>
                    <td><?php echo $list['numero']; ?></td>
                    <td><?php echo $list['CNI']; ?></td>
                    <td><?php echo $list['dateEntree']; ?></td>
                     <td><?php echo $list['dateSortie']; ?></td>
                    <td><?php echo $list['appartement']; ?></td>
                    
                    <td><?php echo $list['montantPaye']; ?>Fbu</td>
                  
                  <td>
                    <a onClick="return confirm('voulez vous modifier?')" href="editerLocataire.php?id_locataire=<?php echo $list['id_locataire'];?>"><button class="btn btn-large btn-primary" type="button">Editer</button></a>
                  </td>
       
                    
                  <?php } ?>
                    
                  </tr>
                  <!--
                  <tr>
                    <th>montant total</th>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                    <?php 
                     $recupdata=$pdo->prepare("SELECT sum(montantPaye) from locataires");
                       $recupdata->execute();
                       while ($list=$recupdata->fetch()){   


                     ?>
                     <td> <?php echo $list['sum(montantPaye)']  ?> Fbu</td>
                       
                       <?php } ?>
                     
                  </tr>
                  -->
                 
                </tbody>
              </table>
              <center>
               


      <ul class="pagination">
           
   <li>
            <?php
       //$numeparpage * $start;
        for($i=0;$i<$numlinks;$i++){
          $y=$i+1;
        echo '<a  href="locataires.php?start='.$i.' ">'.$y.'</a> ';
      } ?>
      </li>
                 
                
           
      </ul>

                
              </center>
            </section>
          </div>
         
        </div>



      </section>
      <div class="text-right">
        <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
          Designed by Armel Nishirimbere
        </div>
      </div>
    </section>
    <!--main content end-->
  </section>
  <!-- container section start -->

  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <<script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>



    <script type="text/javascript">
      function my_fun(str){
        if (window.XMLHttpRequest) {
          xmlhttp=new XMLHttpRequest();
        }else{
          xmlhttp=new activeXobject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
          if(this.readyState==4 && this.status=200){
            document.getElementById('poll').innerHTML=this.responseText;
          }
        }
        xmlhttp.open("GET","helper.php?value="+str,true);
        xmlhttp.send();
      }
    </script>

</body>

</html>
