<?php
//connexion(formulaire avec base de donnees)
 if (isset($_POST['submit'])) {
 $login=htmlentities($_POST['EmailUser']);
 $pass=sha1($_POST['PasswordUse']);
 if (!empty($_POST['EmailUser']) AND !empty($_POST['PasswordUse'])) {
 if(filter_var($login, FILTER_VALIDATE_EMAIL)){
 	//execution de la requete d'authentification
 	$look=$pdo->prepare("SELECT * from usersapprtm where EmailUsers=? and passwords=?");
 	$look->execute(array($login,$pass));
 	$trouve=$look->rowCount();
 	if ($trouve==1) {
 		$userinfo=$look->fetch();
 		$_SESSION['IdUsers']=$userinfo['IdUsers'];
 		$_SESSION['Nom_Users']=$userinfo['Nom_Users'];
 		$_SESSION['EmailUsers']=$userinfo['EmailUsers'];
 		$_SESSION['PasswordUse']=$userinfo['PasswordUse'];
 		header("location:index.php");

 	}else{
 		$error="mauvais identifiant";
 }
 	//verification de l'email
 }else{
   $error="votre email n'est pas valide";
 } //be sure that all fields are felled out
 }else{
 	$error="veuillez remplir tout les champs";
 }
 }
  ?>