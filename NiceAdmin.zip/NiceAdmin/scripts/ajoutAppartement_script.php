 <?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$name =htmlspecialchars($_POST['appartement']);
	$name=utf8_encode($name);
	$name=utf8_decode($name);
	if (! empty($_POST['appartement'])){
    // insertion dans la base de donnees 
	$req=$pdo->prepare("INSERT INTO Appartements(appartement) VALUES(?)");

	$req->execute(array($name));
	$compter=$req->rowCount();
		if ($req){
			$success="enregistrement reussi!!";
		}
	}else{
		$error="veuillez saisir l'Appartement";
	}
	
	
 
}
 ?>
 