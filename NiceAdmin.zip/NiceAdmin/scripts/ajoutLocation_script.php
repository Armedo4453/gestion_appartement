<?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$appartement =htmlspecialchars($_POST['appartement']);
	$appartement=utf8_encode($appartement);
	$appartement=utf8_decode($appartement);
	$location=htmlentities($_POST['location']);
    // insertion dans la base de donnees 
	$req=$pdo->prepare("INSERT INTO locations(appartement,location) VALUES(?,?)");
	$req->execute(array($appartement,$location));
	$compter=$req->rowCount();
		if ($req){
			$success="enregistrement reussi!!";
		}
	
 
}
 ?>