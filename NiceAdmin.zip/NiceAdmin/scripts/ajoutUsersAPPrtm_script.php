<?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$fullnameUs =htmlentities($_POST['UtilisateurNam']);
	$mailUs =htmlentities($_POST['EmailUser']);
	$passwordUs =sha1($_POST['PasswordUse']);
	if(preg_match('#[A-Za-z]#',$fullnameUs )){	
	if(filter_var($mailUs, FILTER_VALIDATE_EMAIL)){

    $verifuser=$pdo->prepare("SELECT * FROM usersapprtm WHERE EmailUsers=? ");
		$verifuser->execute(array($mailUs));
		$exist=$verifuser->rowCount();
		if($exist==0){

    // insertion dans la base de donnees 
		$req=$pdo->prepare("INSERT INTO usersapprtm(Nom_Users, EmailUsers, passwords) VALUES(?,?,?)");

		$req->execute(array($fullnameUs,$mailUs,$passwordUs));
		if ($req){
			$success="inscription reussie ...";
		}
	}else{
		$error="le mail (".$mailUs.") est deja utilise";
	}
	}else{
			$error="voter Email est invalide";
		}
	}else{
			$error ="votre nom(".$fullnameUs.") n'est pas valide(ex:Armel)";
		}
 
}
 ?>
 