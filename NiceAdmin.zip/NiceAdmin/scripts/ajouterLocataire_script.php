
<?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$client=htmlspecialchars($_POST['locataire']);
	$sexe=htmlspecialchars($_POST['sexe']);
	$adress=htmlspecialchars($_POST['adresse']);
	$numero=htmlspecialchars($_POST['numero']);
	$CNI=htmlspecialchars($_POST['CNI']);
	$dateEntree=htmlspecialchars($_POST['dateEntree']);
	$dateSortie=htmlspecialchars($_POST['dateSortie']);
    $appartement=htmlspecialchars($_POST['appartement']);
    $montantpay=htmlspecialchars($_POST['montantpay']);
   
    // insertion dans la base de donnees

	$req=$pdo->prepare("INSERT INTO locataires(nom_locataire,sexe,adresse,numero,CNI,dateEntree,dateSortie,appartement,montantpaye) VALUES(?,?,?,?,?,?,?,?,?)");
	$req->execute(array($client,$sexe,$adress,$numero,$CNI,$dateEntree,$dateSortie,$appartement,$montantpay));
	$compter=$req->rowCount();
		if ($req){
			$success="ajout reussi!!";
		}
	

}
?>


