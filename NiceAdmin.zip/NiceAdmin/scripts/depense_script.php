
<?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$namedep=htmlspecialchars($_POST['employeur']);
	$appartement=htmlspecialchars($_POST['appartement']);
	$motif=htmlspecialchars($_POST['motif']);
	$date=htmlspecialchars($_POST['date']);
	$montantdep=htmlspecialchars($_POST['montant']);
   
    // insertion dans la base de donnees

	$req=$pdo->prepare("INSERT INTO depenses(nom_depense,appartement,motif,date,montantDepense) VALUES(?,?,?,?,?)");
	$req->execute(array($namedep,$appartement,$motif,$date,$montantdep));
	$compter=$req->rowCount();
		if ($req){
			$success="ajout reussi!!";
		}
	

}
?>


