<?php 
//condition pour recuperer ce qui se trouve dans le database

if(isset($_GET['id_appartement'])){
$user=intval($_GET['id_appartement']);
$query=$pdo->prepare("SELECT * from appartements where id_appartement=?");
$query->execute(array($user));
$ok=$query->fetch();

//requete pour modifier la categorie dans le form
if(isset($_POST['appartement']) and !empty($_POST['appartement']) and $_POST['appartement']!= $ok['appartement']){
	$newname=htmlentities($_POST['appartement']);
	$nouveaunom=$pdo->prepare("UPDATE appartements SET appartement=? WHERE id_appartement=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:Appartement.php");
	
}

}

 ?>
