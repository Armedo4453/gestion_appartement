<?php 
//condition pour recuperer ce qui se trouve dans le database

if(isset($_GET['id_depense'])){
$user=intval($_GET['id_depense']);
$query=$pdo->prepare("SELECT * from depenses where id_depense=?");
$query->execute(array($user));
$ok=$query->fetch();

//requete pour modifier la categorie dans le form
if(isset($_POST['nom_depense']) and !empty($_POST['nom_depense']) and $_POST['nom_depense']!= $ok['nom_depense']){  
	$newname=htmlentities($_POST['nom_depense']);
	$nouveaunom=$pdo->prepare("UPDATE depenses SET nom_depense=? WHERE id_depense=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:depenses.php?start=0");
	
}
if(isset($_POST['motif']) and !empty($_POST['motif']) and $_POST['motif']!= $ok['motif']){
	$newname=htmlentities($_POST['motif']);
	$nouveaunom=$pdo->prepare("UPDATE depenses SET motif=? WHERE id_depense=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:depenses.php?start=0");
	
}
if(isset($_POST['date']) and !empty($_POST['date']) and $_POST['date']!= $ok['date']){
	$newname=htmlentities($_POST['date']);
	$nouveaunom=$pdo->prepare("UPDATE depenses SET date=? WHERE id_depense=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:depenses.php?start=0");
	
}
if(isset($_POST['montant']) and !empty($_POST['montant']) and $_POST['montant']!= $ok['montantDepense']){
	$newname=htmlentities($_POST['montant']);
	$nouveaunom=$pdo->prepare("UPDATE depenses SET montantDepense=? WHERE id_depense=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:depenses.php?start=0");
	
}

}

 ?>
