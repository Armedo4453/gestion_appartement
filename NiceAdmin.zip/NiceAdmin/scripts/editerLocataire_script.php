<?php 
//condition pour recuperer ce qui se trouve dans le database

if(isset($_GET['id_locataire'])){
$user=intval($_GET['id_locataire']);
$query=$pdo->prepare("SELECT * from locataires where id_locataire=?");
$query->execute(array($user));
$ok=$query->fetch();

//requete pour modifier la categorie dans le form
if(isset($_POST['locataire']) and !empty($_POST['locataire']) and $_POST['locataire']!= $ok['nom_locataire']){  
	$newname=htmlentities($_POST['locataire']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET nom_locataire=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['sexe']) and !empty($_POST['sexe']) and $_POST['sexe']!= $ok['sexe']){
	$newname=htmlentities($_POST['sexe']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET sexe=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['adresse']) and !empty($_POST['adresse']) and $_POST['adresse']!= $ok['adresse']){
	$newname=htmlentities($_POST['adresse']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET appartement=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['numero']) and !empty($_POST['numero']) and $_POST['numero']!= $ok['numero']){
	$newname=htmlentities($_POST['numero']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET numero=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['CNI']) and !empty($_POST['CNI']) and $_POST['CNI']!= $ok['CNI']){
	$newname=htmlentities($_POST['CNI']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET CNI=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['dateEntree']) and !empty($_POST['dateEntree']) and $_POST['dateEntree']!= $ok['dateEntree']){
	$newname=htmlentities($_POST['dateEntree']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET dateEntree=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}
if(isset($_POST['dateSortie']) and !empty($_POST['dateSortie']) and $_POST['dateSortie']!= $ok['dateSortie']){
	$newname=htmlentities($_POST['dateSortie']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET dateSortie=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}

if(isset($_POST['montantpay']) and !empty($_POST['montantpay']) and $_POST['montantpay']!= $ok['montantPaye']){
	$newname=htmlentities($_POST['montantpay']);
	$nouveaunom=$pdo->prepare("UPDATE locataires SET montantPaye=? WHERE id_locataire=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locataires.php?start=0");
	
}

}

 ?>
