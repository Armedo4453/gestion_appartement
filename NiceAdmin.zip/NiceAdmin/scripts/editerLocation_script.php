<?php 
//condition pour recuperer ce qui se trouve dans le database

if(isset($_GET['id_locations'])){
$user=intval($_GET['id_locations']);
$query=$pdo->prepare("SELECT * from locations where id_locations=?");
$query->execute(array($user));
$ok=$query->fetch();

//requete pour modifier le nom du produit dans le form


if(isset($_POST['appartement']) and !empty($_POST['appartement']) and $_POST['appartement']!= $ok['id_appartement']){
	$newname=htmlentities($_POST['appartement']);
	$nouveaunom=$pdo->prepare("UPDATE locations SET appartement=? WHERE id_locations=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locations.php");
	
}
//pour modifier la quantite dans le form
if(isset($_POST['location']) and !empty($_POST['location']) and $_POST['location']!= $ok['location']){
	$newname=htmlentities($_POST['location']);
	$nouveaunom=$pdo->prepare("UPDATE locations SET location=? WHERE id_locations=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:locations.php");
	
}


}

 ?>