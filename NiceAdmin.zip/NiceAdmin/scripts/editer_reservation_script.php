<?php 
//condition pour recuperer ce qui se trouve dans le database

if(isset($_GET['id_reservation'])){
$user=intval($_GET['id_reservation']);
$query=$pdo->prepare("SELECT * from reservations where id_reservation=?");
$query->execute(array($user));
$ok=$query->fetch();

//requete pour modifier la categorie dans le form
if(isset($_POST['locataire']) and !empty($_POST['locataire']) and $_POST['locataire']!= $ok['nom_locataire']){  
	$newname=htmlentities($_POST['locataire']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET nom_locataire=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['sexe']) and !empty($_POST['sexe']) and $_POST['sexe']!= $ok['sexe']){
	$newname=htmlentities($_POST['sexe']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET sexe=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['adresse']) and !empty($_POST['adresse']) and $_POST['adresse']!= $ok['adresse']){
	$newname=htmlentities($_POST['adresse']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET appartement=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['numero']) and !empty($_POST['numero']) and $_POST['numero']!= $ok['numero']){
	$newname=htmlentities($_POST['numero']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET numero=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['CNI']) and !empty($_POST['CNI']) and $_POST['CNI']!= $ok['CNI']){
	$newname=htmlentities($_POST['CNI']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET CNI=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['date']) and !empty($_POST['date']) and $_POST['date']!= $ok['date']){
	$newname=htmlentities($_POST['date']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET date=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['appartement']) and !empty($_POST['location']) and $_POST['location']!= $ok['location']){
	$newname=htmlentities($_POST['location']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET location=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}
if(isset($_POST['montantpay']) and !empty($_POST['montantpay']) and $_POST['montantpay']!= $ok['montantPaye']){
	$newname=htmlentities($_POST['montantpay']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET montantPaye=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}

if(isset($_POST['montantrest']) and !empty($_POST['montantrest']) and $_POST['montantrest']!= $ok['montantReste']){
	$newname=htmlentities($_POST['montantrest']);
	$nouveaunom=$pdo->prepare("UPDATE reservations SET montantReste=? WHERE id_reservation=?");
	$nouveaunom->execute(array($newname,$user));
	header("location:reservations.php?start=0");
	
}

}

 ?>
