<?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['submit'])){
	$client=htmlspecialchars($_POST['locataire']);
	$sexe=htmlspecialchars($_POST['sexe']);
	$adress=htmlspecialchars($_POST['adresse']);
	$numero=htmlspecialchars($_POST['numero']);
	$CNI=htmlspecialchars($_POST['CNI']);
	$date=htmlspecialchars($_POST['date']);
    $location=htmlspecialchars($_POST['location']);
    $montantpay=htmlspecialchars($_POST['montantpay']);
    $montantrest=htmlspecialchars($_POST['montantrest']);
    // insertion dans la base de donnees

	$req=$pdo->prepare("INSERT INTO reservations(nom_locataire,sexe,adresse,numero,CNI,date,location,montantpaye,montantreste) VALUES(?,?,?,?,?,?,?,?,?)");
	$req->execute(array($client,$sexe,$adress,$numero,$CNI,$date,$location,$montantpay,$montantrest));
	$compter=$req->rowCount();
		if ($req){
			$success="ajout reussi!!";
		}
	

}
?>


