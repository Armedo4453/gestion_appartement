 <?php  
//connexion(formulaire avec base de donnees)
if(isset($_POST['search'])){
	$txtStartDate =htmlspecialchars($_POST['txtStartDate']);
	$txtEndDate =htmlspecialchars($_POST['txtEndDate']);
	if (! empty($_POST['txtStartDate']) and !empty($_POST['txtEndDate'])){
    // insertion dans la base de donnees 
	$req=$pdo->prepare("SELECT * from locataires WHERE date between '$txtStartDate' and '$txtEndDate'");

	$req->execute(array($txtStartDate,$txtEndDate));
	$compter=$req->rowCount();
		if ($req){
			$success="enregistrement reussi!!";
		}
	}else{
		$error="veuillez entrer la date";
	}
	
	
 
}
 ?>
 