<!DOCTYPE html>
<html>
<head>
	<title>PHP Dependent Dropdown List</title>
</head>
<style>
	select.country{
		padding:10px;
		color:red;
		margin:100px;
		align:center;
		width:30%;
		border:5px;
	}
	
	select.state{
		padding:10px;
		color:blue;
		margin:100px;
		align:center;
		border:5px;
		width:30%;
	}
	.selectDiv{
		background-color:#0cd1ad;
		width:100%;
		height:300px;
	}
	.tileDiv{
		text-align:center;
		margin:0 20px;
		padding:10px;
		font-weight:bold;
		font-size:28px;
	}
</style>
<body>
<div class="tileDiv">Dependent Dropdown in PHP without Ajax</div>
<div class="selectDiv">
<select class="country" id="country" onchange="updateState();">Country
</select>
<select class="state" id="state" >State
</select>
</div>
<script>
	var myArrayCountry = [
	  {
		"country" : "India"
	  },
	  {
		"country" : "United States"
	  },
	  {
		"country" : "United Kingdom"
	  }
	];

	function updateState() {
		var zone = document.getElementById("country");

		if (zone.value == "India"){

			alert("You clicked India.");
			var myArrayState = [
			  {
				"state" : "Maharashtra"
			  },
			  {
				"state" : "Kerala"
			  }
			];
			stateFunction(myArrayState)
		}
		
		if (zone.value == "United States"){

			alert("You clicked United States.");
			var myArrayState = [
			  {
				"state" : "Washington"
			  },
			  {
				"state" : "New York"
			  }
			];
			stateFunction(myArrayState)
		}
		
		if (zone.value == "United Kingdom"){

			alert("You clicked United Kingdom.");
			var myArrayState = [
			  {
				"state" : "London"
			  },
			  {
				"state" : "Scotland"
			  },
			  {
				"state" : "Wales"
			  }
			];
			stateFunction(myArrayState)
		}
	}
	countryFunction(myArrayCountry);
	function countryFunction(arr) {
	  var out = "";
	  var i;
	  
	  for(i = 0; i < arr.length; i++) {
		out += '<option value="' + arr[i].country + '">' + arr[i].country + '</option>' + 
		arr[i].display + '</a><br>';
	  }
	  document.getElementById("country").innerHTML = out;
	}
	var myArrayState = [
		{
			"state" : "Maharashtra"
		},
		{
			"state" : "Kerala"
		}
	];
	stateFunction(myArrayState);
	function stateFunction(arr) {
	  var out = "";
	  var i;
	  
	  for(i = 0; i < arr.length; i++) {
		out += '<option value="' + arr[i].state + '">' + arr[i].state + '</option>' + 
		arr[i].display + '</a><br>';
	  }
	  document.getElementById("state").innerHTML = out;
	}
</script>
</body>
</html>